---
title: Gear I use
---

{{< youtube 6mZTVpFeyrs >}}