---
Title: Public Speaking
type: list
---

Different talks/presentations I have given at Conferences

## 2023:

- [Is PaaS the DevOps Killer? at RefactorDX Toronto](https://youtu.be/BV18fTSjZkw)
- [SMS Alerts for GitHub Actions at Civo Navigate NA](https://www.civo.com/navigate/north-america-2023/talks/rooftop/rishab-kumar-sms-alerts-for-github-actions)