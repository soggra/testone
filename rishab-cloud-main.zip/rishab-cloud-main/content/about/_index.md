---
Title: About me
type: list
---


I am a Developer Evangelist at Twilio, co-author of Learn to Cloud, co-host of Random Cloud Chats podcast, AWS Community Builder, and YouTuber. Passionate about helping people get into cloud and sharing my learnings in cloud, DevOps and now DevRel.

If you have a short message or question, drop a message via [LinkedIn](https://www.linkedin.com/in/rishabkumar7/).

## YouTube

A day in my life:

{{< youtube DY2gJhJaQfI >}}

My career journey:

{{< youtube JyBipEz334A >}}
