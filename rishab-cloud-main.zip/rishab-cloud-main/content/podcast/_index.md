---
Title: Podcast
type: list
---

## Tech Careers

[![Spotify](https://img.shields.io/badge/Spotify-1ED760?style=for-the-badge&logo=spotify&logoColor=white)](https://open.spotify.com/show/3B9KfnLOmJzQo5yKdJC7Mg?si=c751a71589b34b98) [![Apple Podcasts](https://img.shields.io/badge/Apple_Podcast-9933CC?style=for-the-badge&logo=apple-music&logoColor=white)](https://podcasts.apple.com/us/podcast/tech-careers/id1666342611) [![YouTube](https://img.shields.io/badge/YouTube-FF0000?style=for-the-badge&logo=youtube-music&logoColor=white)](https://youtube.com/playlist?list=PLK_LRl1CH4L906X-VE7GIESCMF03JVIQR)

### Episodes

{{< podcast width="100%" height="120" >}}
