---
title: Cloud Notes
---

Found this helpful? Give it a star on [GitHub](https://github.com/rishabkumar7/CloudNotes).
[![GitHub followers](https://img.shields.io/github/followers/rishabkumar7?label=Rishab%20Kumar&style=social)](https://github.com/rishabkumar7/)[![GitHub Repo stars](https://img.shields.io/github/stars/rishabkumar7/CloudNotes?style=social)](https://github.com/rishabkumar7/CloudNotes)